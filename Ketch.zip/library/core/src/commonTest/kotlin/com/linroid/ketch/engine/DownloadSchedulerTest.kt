package com.linroid.ketch.engine

import com.linroid.ketch.api.Destination
import com.linroid.ketch.api.DownloadCondition
import com.linroid.ketch.api.DownloadPriority
import com.linroid.ketch.api.DownloadRequest
import com.linroid.ketch.api.DownloadSchedule
import com.linroid.ketch.api.DownloadState
import com.linroid.ketch.api.Segment
import com.linroid.ketch.api.DownloadConfig
import com.linroid.ketch.core.KetchDispatchers
import com.linroid.ketch.core.engine.DownloadCoordinator
import com.linroid.ketch.core.engine.DownloadQueue
import com.linroid.ketch.core.engine.DownloadScheduler
import com.linroid.ketch.core.engine.HttpDownloadSource
import com.linroid.ketch.core.engine.SourceResolver
import com.linroid.ketch.core.file.DefaultFileNameResolver
import com.linroid.ketch.core.task.AtomicSaver
import com.linroid.ketch.core.task.TaskHandle
import com.linroid.ketch.core.task.TaskRecord
import com.linroid.ketch.core.task.TaskState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertTrue
import kotlin.time.Clock
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds
import kotlin.time.Instant

class DownloadSchedulerTest {

  private fun createRequest(
    schedule: DownloadSchedule = DownloadSchedule.Immediate,
    conditions: List<DownloadCondition> = emptyList(),
  ) = DownloadRequest(
    url = "https://example.com/file.zip",
    destination = Destination("/tmp/"),
    schedule = schedule,
    conditions = conditions,
    priority = DownloadPriority.NORMAL,
  )

  private fun createHandle(
    taskId: String,
    request: DownloadRequest = createRequest(),
    createdAt: Instant = Clock.System.now(),
  ): TaskHandle {
    val record = TaskRecord(
      taskId = taskId,
      request = request,
      state = TaskState.QUEUED,
      createdAt = createdAt,
      updatedAt = createdAt,
    )
    return object : TaskHandle {
      override val taskId = taskId
      override val request = request
      override val createdAt = createdAt
      override val mutableState =
        MutableStateFlow<DownloadState>(DownloadState.Queued)
      override val mutableSegments =
        MutableStateFlow<List<Segment>>(emptyList())
      override val record = AtomicSaver(record) {}
    }
  }

  private fun createTestComponents(
    scope: CoroutineScope,
  ): Pair<DownloadQueue, DownloadScheduler> {
    val engine = FakeHttpEngine()
    val source = HttpDownloadSource(
      httpEngine = engine,
    )
    val coordinator = DownloadCoordinator(
      sourceResolver = SourceResolver(listOf(source)),
      config = DownloadConfig(),
      fileNameResolver = DefaultFileNameResolver(),
      dispatchers = KetchDispatchers(
        main = Dispatchers.Default,
        network = Dispatchers.Default,
        io = Dispatchers.Default,
      ),
    )
    val scheduler = DownloadQueue(
      maxConcurrentDownloads = 10,
      maxConnectionsPerHost = 0,
      coordinator = coordinator,
    )
    val manager = DownloadScheduler(scheduler, scope)
    return scheduler to manager
  }

  @Test
  fun afterDelay_enqueuesAfterDelay() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        val handle = createHandle(
          "task-1",
          createRequest(
            schedule = DownloadSchedule.AfterDelay(200.milliseconds),
          ),
        )

        manager.schedule(handle)

        assertIs<DownloadState.Scheduled>(handle.mutableState.value)
        assertTrue(manager.isScheduled("task-1"))
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun atTime_setsScheduledState() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        val futureTime = Clock.System.now() + 10.seconds
        val handle = createHandle(
          "task-1",
          createRequest(
            schedule = DownloadSchedule.AtTime(futureTime),
          ),
        )

        manager.schedule(handle)

        val state = handle.mutableState.value
        assertIs<DownloadState.Scheduled>(state)
        assertEquals(
          DownloadSchedule.AtTime(futureTime),
          state.schedule,
        )
        assertTrue(manager.isScheduled("task-1"))
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun atTime_pastTime_enqueuesImmediately() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        // Schedule in the past — should fire immediately
        val pastTime = Clock.System.now() - 1.seconds
        val handle = createHandle(
          "task-1",
          createRequest(
            schedule = DownloadSchedule.AtTime(pastTime),
          ),
        )

        manager.schedule(handle)

        // Should transition out of Scheduled quickly
        withTimeout(2.seconds) {
          handle.mutableState.first { it !is DownloadState.Scheduled }
        }
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun immediate_withConditions_waitsForCondition() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val conditionMet = MutableStateFlow(false)
        val condition = DownloadCondition.Test(conditionMet)

        val (_, manager) = createTestComponents(scope)

        val handle = createHandle(
          "task-1",
          createRequest(
            schedule = DownloadSchedule.Immediate,
            conditions = listOf(condition),
          ),
        )

        manager.schedule(handle)

        // Should be in Scheduled state while waiting for condition
        assertIs<DownloadState.Scheduled>(handle.mutableState.value)

        // Meet the condition
        conditionMet.value = true

        // Wait for the scheduler to pick it up
        withTimeout(2.seconds) {
          handle.mutableState.first { it !is DownloadState.Scheduled }
        }

        // Should have moved past Scheduled
        val state = handle.mutableState.value
        assertTrue(
          state !is DownloadState.Scheduled,
          "Expected non-Scheduled state, got $state",
        )
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun multipleConditions_allMustBeMet() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val condition1Met = MutableStateFlow(false)
        val condition2Met = MutableStateFlow(false)
        val cond1 = DownloadCondition.Test(condition1Met)
        val cond2 = DownloadCondition.Test(condition2Met)

        val (_, manager) = createTestComponents(scope)

        val handle = createHandle(
          "task-1",
          createRequest(conditions = listOf(cond1, cond2)),
        )

        manager.schedule(handle)

        assertIs<DownloadState.Scheduled>(handle.mutableState.value)

        // Meet only the first condition — should still wait
        condition1Met.value = true
        delay(200)
        assertIs<DownloadState.Scheduled>(handle.mutableState.value)

        // Meet the second condition — now should proceed
        condition2Met.value = true

        withTimeout(2.seconds) {
          handle.mutableState.first { it !is DownloadState.Scheduled }
        }
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun cancel_stopsScheduledTask() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        // Schedule with long delay
        val handle = createHandle(
          "task-1",
          createRequest(
            schedule = DownloadSchedule.AfterDelay(10.seconds),
          ),
        )
        manager.schedule(handle)

        assertTrue(manager.isScheduled("task-1"))

        // Cancel it
        manager.cancel("task-1")

        delay(100)
        assertTrue(
          !manager.isScheduled("task-1"),
          "Task should no longer be scheduled after cancel",
        )
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun cancel_nonExistentTask_doesNothing() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        // Should not throw
        manager.cancel("non-existent")
        assertFalse(manager.isScheduled("non-existent"))
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun isScheduled_returnsFalseForUnknownTask() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)
        assertFalse(manager.isScheduled("unknown"))
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun reschedule_setsScheduledState() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        val handle = createHandle("task-1")
        handle.mutableState.value = DownloadState.Paused(
          com.linroid.ketch.api.DownloadProgress(500, 1000),
        )

        val newSchedule = DownloadSchedule.AfterDelay(10.seconds)

        manager.reschedule(handle, newSchedule, emptyList())

        val state = handle.mutableState.value
        assertIs<DownloadState.Scheduled>(state)
        assertEquals(newSchedule, state.schedule)
        assertTrue(manager.isScheduled("task-1"))
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun reschedule_cancelsOldScheduleJob() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        val handle = createHandle(
          "task-1",
          createRequest(
            schedule = DownloadSchedule.AfterDelay(10.seconds),
          ),
        )

        // Schedule with long delay
        manager.schedule(handle)
        assertTrue(manager.isScheduled("task-1"))

        // Reschedule with short delay — old job should be canceled
        val shortDelay = DownloadSchedule.AfterDelay(100.milliseconds)
        manager.reschedule(handle, shortDelay, emptyList())

        val state = handle.mutableState.value
        assertIs<DownloadState.Scheduled>(state)
        assertEquals(shortDelay, state.schedule)

        // New schedule should fire quickly
        withTimeout(2.seconds) {
          handle.mutableState.first { it !is DownloadState.Scheduled }
        }
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun reschedule_withConditions_waitsForConditions() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val conditionMet = MutableStateFlow(false)
        val condition = DownloadCondition.Test(conditionMet)

        val (_, manager) = createTestComponents(scope)

        val handle = createHandle("task-1")
        handle.mutableState.value = DownloadState.Paused(
          com.linroid.ketch.api.DownloadProgress(500, 1000),
        )

        manager.reschedule(
          handle, DownloadSchedule.Immediate,
          listOf(condition),
        )

        // Should be Scheduled while waiting for condition
        assertIs<DownloadState.Scheduled>(handle.mutableState.value)

        // Still waiting
        delay(200)
        assertIs<DownloadState.Scheduled>(handle.mutableState.value)

        // Meet the condition
        conditionMet.value = true

        withTimeout(2.seconds) {
          handle.mutableState.first { it !is DownloadState.Scheduled }
        }
      } finally {
        scope.cancel()
      }
    }
  }

  @Test
  fun afterDelay_enqueuesMovesPastScheduled() = runTest {
    withContext(Dispatchers.Default) {
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
      try {
        val (_, manager) = createTestComponents(scope)

        val handle = createHandle(
          "task-1",
          createRequest(
            schedule = DownloadSchedule.AfterDelay(100.milliseconds),
          ),
        )

        manager.schedule(handle)

        assertIs<DownloadState.Scheduled>(handle.mutableState.value)

        // After the delay fires, state should move past Scheduled
        withTimeout(2.seconds) {
          handle.mutableState.first { it !is DownloadState.Scheduled }
        }

        // And the job should be cleaned up
        delay(100)
        assertFalse(manager.isScheduled("task-1"))
      } finally {
        scope.cancel()
      }
    }
  }
}
