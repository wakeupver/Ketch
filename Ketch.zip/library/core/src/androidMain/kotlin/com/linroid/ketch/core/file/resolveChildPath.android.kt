@file:Suppress("UseKtx")

package com.linroid.ketch.core.file

import android.net.Uri
import android.provider.DocumentsContract
import com.linroid.ketch.core.AndroidContext
import okio.Path.Companion.toPath

internal actual fun resolveChildPath(
  directory: String,
  fileName: String,
): String {
  val uri = Uri.parse(directory)
  if (uri.scheme == "content") {
    val parentDocUri = if (DocumentsContract.isTreeUri(uri)) {
      DocumentsContract.buildDocumentUriUsingTree(
        uri,
        DocumentsContract.getTreeDocumentId(uri),
      )
    } else {
      uri
    }
    val docUri = DocumentsContract.createDocument(
      AndroidContext.get().contentResolver,
      parentDocUri,
      "application/octet-stream",
      fileName,
    ) ?: throw IllegalStateException(
      "Failed to create document '$fileName' in $directory"
    )
    return docUri.toString()
  }
  return (directory.toPath() / fileName).toString()
}
