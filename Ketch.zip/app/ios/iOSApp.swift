import SwiftUI
import KetchApp

@main
struct iOSApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
